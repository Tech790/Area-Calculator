from django.contrib import admin
from django.urls import path
from myapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.home,name='home'),
    path('area/',views.area,name='area'),
    path('rectangle/',views.rectangle,name='rectangle'),
    path('triangle/',views.triangle,name='triangle'),
    path('square',views.square,name='square'),
    path('hexagon',views.hexagon,name='hexagon'),
    path('octagon',views.octagon,name='octagon'),
]
