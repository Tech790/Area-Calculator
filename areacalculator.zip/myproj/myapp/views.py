from django.shortcuts import render,HttpResponse
from django.http import JsonResponse
import math

# Create your views here.
def home(request):
	return render(request,'myapp/home.html')


def area(request):
	if request.method == 'POST':
		area_id = request.POST.get('area_id')
		convert_to_float = float(area_id)
		area_formula = (3.14*convert_to_float**2)
		return JsonResponse({'status':1,'area_output':area_formula})
	else:
		return JsonResponse({'status':0})


def rectangle(request):
	if request.method == 'POST':
		length = request.POST.get('length')
		width = request.POST.get('width')
		area = float(length) * float(width)
		return JsonResponse({'status':1,'rectangle_area':area})
	else:
		return JsonResponse({'status':0})

def triangle(request):
	if request.method == 'POST':
		height = request.POST.get('height')
		base = request.POST.get('base')
		area = (float(height)*float(base))/2
		return JsonResponse({'status':1,'area_of_triangle':area})
	else:
		return JsonResponse({'status':0})

def square(request):
	if request.method == 'POST':
		side = request.POST.get('side')
		area = (float(side)*float(side))
		return JsonResponse({'status':1,'area_of_square':area})
	else:
		return JsonResponse({'status':0})


def hexagon(request):
	if request.method == 'POST':
		hexagon = request.POST.get('hexagon')
		s = float(hexagon)
		area = ((3 * math.sqrt(3) * (s * s)) / 2)
		return JsonResponse({'status':1,'area_of_hexagon':area})
	else:
		return JsonResponse({'status':0})


def octagon(request):
	if request.method == 'POST':
		octagon = request.POST.get('octagon')
		s = float(octagon)
		# area = ((3 * math.sqrt(3) * (s * s)) / 2)
		area = (2*(1+math.sqrt(2))*(s*s))
		return JsonResponse({'status':1,'area_of_octagon':area})
	else:
		return JsonResponse({'status':0})